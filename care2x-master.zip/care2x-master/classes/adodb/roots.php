<?php
$root_path='../../';
/* We will try to see where we are */
/*$doc_root=ini_get('doc_root');
$top_dir=str_replace($doc_root,'',getcwd());
$root_path='';
$top_dir=strtr($top_dir,'\\','/');
if(!($b2=substr_count($top_dir,'/'))) {
    $root_path='./';
} else {
    for($i=0;$i<$b2; $i++) $root_path.='../';
}
*/
?>
