<?php

header("location: image.php?code=22000029&style=68&type=I25&width=145&height=50&xres=2&font=5&sid=$ck_sid&lang=$lang&pn=$pn&label=1");
?>
