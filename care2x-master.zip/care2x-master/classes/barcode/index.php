<?php
error_reporting($ErrorLevel);
include("home.php");
?>
