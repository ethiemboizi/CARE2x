# Care2x
This is a movement to provide new impetus to the Care2x project which has stagnated for a few years.

The latest code can be downloaded from https://github.com/care2x/care2x/archive/master.zip

To install this code

1. unzip the archive under your web server, point your browser at the code and follow the instructions.
2. You _may_ need to change permissions for the directories cache, installer and uploads so care2x installer can be able to write to these.

   - In case the __cache__ directory doesn't exists, you'll need to create it.

I have created a demo of the latest code from github here https://care2x.kwamoja.org/. The username/password is admin/kwamoja. This uses a blank database so that people can check out and test the config as well. This will be constantly updated from github so may be broken at any time, but comments/bug reports are welcomed.
